<?php
    $sql = 'INSERT INTO sessions (session, id_user) VALUES (:session, :id_user)';
    $sth = $dbh->prepare($sql);
    $sth->bindValue(':session', $key);
    $sth->bindValue(':id_user', $_POST['logIn']);
    $sth->execute();
?>