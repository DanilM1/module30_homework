<?php
    $sql = 'SELECT id_user, date, comment FROM comments WHERE id_image = ? ORDER BY date DESC';
    $sth = $dbh->prepare($sql);
    $sth->execute(array(substr($name, 0, -4)));
?>