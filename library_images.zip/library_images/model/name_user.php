<?php
    $sql = 'SELECT id_user FROM users WHERE id_user = ?';
    $sth = $dbh->prepare($sql);
    $sth->execute(array($_POST['register']));
    $answer = $sth->fetch(PDO::FETCH_ASSOC);
?>