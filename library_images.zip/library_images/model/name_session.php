<?php
    $sql = 'SELECT id_user FROM sessions WHERE session = ?';
    $sth = $dbh->prepare($sql);
    $sth->execute(array($_SESSION['user']));
    $answer = $sth->fetch(PDO::FETCH_ASSOC);
?>