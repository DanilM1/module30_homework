<?php
    $sql = 'SELECT id_image FROM images ORDER BY id_image DESC';
    $sth = $dbh->query($sql);
?>