<?php
    $sql = 'INSERT INTO images (id_image, date, id_user) VALUES (:id_image, :date, :id_user)';
    $sth = $dbh->prepare($sql);
    $buf[2] = date("Y-m-d H:i:s");
    $sth->bindValue(':id_image', $buf[1]);
    $sth->bindValue(':date', $buf[2]);
    $sth->bindValue(':id_user', $id);
    $sth->execute();
?>