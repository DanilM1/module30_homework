<?php
    $dbh = new PDO('mysql:host=' . 'localhost'. ';dbname=' . 'library_images', 'root', '');
?>