<?php
    $sql = 'INSERT INTO users (id_user, password, date) VALUES (:id_user, :password, :date)';
    $sth = $dbh->prepare($sql);
    $buf[1] = $_POST['password'];
    $buf[2] = date("Y-m-d H:i:s");
    $sth->bindValue(':id_user', $_POST['register']);
    $sth->bindValue(':password', $buf[1]);
    $sth->bindValue(':date', $buf[2]);
    $sth->execute();
?>