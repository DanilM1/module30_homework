<?php
    $sql = 'SELECT id_user FROM users WHERE id_user = ? AND password = ?';
    $sth = $dbh->prepare($sql);
    $buf[0] = $_POST['logIn'];
    $buf[1] = $_POST['password'];
    $sth->execute(array($buf[0], $buf[1]));
    $answer = $sth->fetch(PDO::FETCH_ASSOC);
?>