<?php
$sql = 'INSERT INTO comments (id_image, comment, date, id_user) VALUES (:id_image, :comment, :date, :id_user)';
$sth = $dbh->prepare($sql);
$buf[0] = substr($name, 0, -4);
$buf[1] = $_POST['add_comment'];
$buf[2] = date("Y-m-d H:i:s");
$sth->bindValue(':id_image', $buf[0]);
$sth->bindValue(':comment', $buf[1]);
$sth->bindValue(':date', $buf[2]);
$sth->bindValue(':id_user', $id);
$sth->execute();
?>