<?php
    $sql = 'SELECT id_image, id_user FROM images WHERE id_image = ?';
    $sth = $dbh->prepare($sql);
    $sth->execute(array($buf[1]));
    $answer = $sth->fetch(PDO::FETCH_ASSOC);
?>