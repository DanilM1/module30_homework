<?php
$sql = 'DELETE FROM `images` WHERE id_image = :id_image';
$sth = $dbh->prepare($sql);
$buf[0] = substr($name, 0, -4);
$sth->bindValue(':id_image', $buf[0]);
$sth->execute();
?>