<?php
    $buf = [];
    $host = 'http://localhost/';
    $nav = ['Images'];
    $logIn = 'LogIn';
    $register = 'Register';
    $library_images = 'library_images/';
    $formats = ['.jpg'];
    $add_image = 'Add image';
    $delete_image = 'Delete this image';
    $add_comment = 'Add comment';
    $exit = 'Exit';
    $close = 'Close';
    $send = 'Send';
    $method_send = ['GET', 'POST'];
    $screen = [70];

    // tables and their columns

    $table_images = ['id_image', 'date', 'id_user'];
    $table_comments = ['id_image', 'date', 'comment', 'id_user'];
?>