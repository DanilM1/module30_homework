<h1><?php echo $name ?></h1>
<img src="./view/images/<?php echo $name ?>" width=<?php echo $screen[0] ?>% alt="<?php echo $name ?>">