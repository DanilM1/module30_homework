<button type="button" form="add_comment" class="m-2 btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModalcomment"><?php echo $add_comment ?></button>

<div class="modal fade" id="exampleModalcomment" tabindex="-1" aria-labelledby="exampleModalLabelcomment" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabelcomment"><?php echo $add_comment ?></h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <form id="add_comment" method="post">
            <div class="mb-3">
                <label for="message-text" class="col-form-label">Comment:</label>
                <textarea class="form-control" id="message-text" name="add_comment"></textarea>
            </div>
            </form>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" data-bs-dismiss="modal"><?php echo $close ?></button>
            <button class="btn btn-primary" form="add_comment"><?php echo $send ?></button>
        </div>
        </div>
    </div>
</div>