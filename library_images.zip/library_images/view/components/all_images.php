<?php
    include './model/all_images.php';

    $images = '';

    while ($answer = $sth->fetch(PDO::FETCH_ASSOC)) {
        $images .=
            '<a href="'.$host.$library_images.$answer[$table_images[0]].$formats[0].'">'
                .'<img src='
                .'"./view/images/'.$answer[$table_images[0]].$formats[0].'" '
                .'class="img-thumbnail we" width=25% alt="'.$answer[$table_images[0]].'">'
            .'</a>';
    }

    echo $images;
?>