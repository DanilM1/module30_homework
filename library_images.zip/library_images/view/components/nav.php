<?php

$n = count($nav);

$nav_view = '<ul class="nav">';

for ($i = 0; $i < $n; $i++) {
    $nav_view .=
        '<li class="nav-item">'
            .'<a class="nav-link" href="'.$nav[$i].'">'.$nav[$i].'</a>'
        .'</li>';
}

if (!$id) {

    $nav_view .=
        '<li class="nav-item">'
            .'<a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#exampleModalLogIn">'.$logIn.'</a>'
        .'</li>';

    $nav_view .=
            '<li class="nav-item">'
                .'<a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#exampleModalRegister">'.$register.'</a>'
            .'</li>';

    $nav_view .= '</ul>';

    $nav_view .=
        '<div class="modal fade" id="exampleModalLogIn" tabindex="-1" aria-labelledby="exampleModalLabelLogIn" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabelLogIn">This form is for You</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form method="post" id="logIn">
                            <div class="mb-3">
                                <label for="id" class="col-form-label">Your ID:</label>
                                <input type="text" class="form-control" id="id" name="logIn">
                            </div>
                            <div class="mb-3">
                                <label for="password" class="col-form-label">Your password:</label>
                                <input type="text" class="form-control" id="password" name="password">
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">'.$close.'</button>
                        <button class="btn btn-primary" form="logIn">'.$send.'</button>
                    </div>
                </div>
            </div>
        </div>';

    $nav_view .=
        '<div class="modal fade" id="exampleModalRegister" tabindex="-1" aria-labelledby="exampleModalLabelRegister" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabelRegister">This form is for You</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form method="post" id="register">
                            <div class="mb-3">
                                <label for="id" class="col-form-label">Your ID:</label>
                                <input type="text" class="form-control" id="id" name="register">
                            </div>
                            <div class="mb-3">
                                <label for="password" class="col-form-label">Your password:</label>
                                <input type="text" class="form-control" id="password" name="password">
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">'.$close.'</button>
                        <button class="btn btn-primary" form="register">'.$send.'</button>
                    </div>
                </div>
            </div>
        </div>';

}

else {

$nav_view .=
    '<li class="nav-item">'
        .'<a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#exampleModal">'.$add_image.'</a>'
    .'</li>';

$nav_view .=
    '<button form="exit" name="exit" value="exit" class="btn btn-primary" >'.$exit.'</button>'
    .'<form method="post" id="exit"></form>';
    
$nav_view .= '</ul>';

$nav_view .=
    '<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">'.$add_image.'</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="fille" method="post" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="formFileDisabled" class="form-label">You can add your image here:</label>
                            <input class="form-control" type="file" name="filename" id="formFileDisabled">
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" data-bs-dismiss="modal">'.$close.'</button>
                    <button class="btn btn-primary" form="fille">'.$send.'</button>
                </div>
            </div>
        </div>
    </div>';

}

echo $nav_view;

?>