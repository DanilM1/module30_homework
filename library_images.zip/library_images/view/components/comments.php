<?php
    include './model/comments.php';

    $list_comments = '';

    while($answer = $sth->fetch(PDO::FETCH_ASSOC)) {
        $list_comments .=
            '<div class="p-2 m-2 bg-info text-dark border border-primary">'
                .'<p>User: '.$answer[$table_comments[3]].' Date: '.$answer[$table_comments[1]].'</p>'
                .'<p>Comment: '.$answer[$table_comments[2]].'</p>'
            .'</div>';
    }
    $list_comments;
    echo $list_comments;
?>