<?php
    include './view/components/head.php';
    include './view/components/nav.php';
    include './view/components/all_images.php';
    include './view/components/end.php';
?>