<?php
include './view/components/head.php';
include './view/components/nav.php';
echo '<div id="image">';
echo '<div class="text-center">';
include './view/components/image.php';
echo '<div class="m-2">';
if ($id) include './view/components/comment.php';
if ($id === $answer['id_user']) echo '<button form="delete_image" name="delete_image" value="delete_image" class="m-2 btn btn-primary">Delete this image</button>
<form method="post" id="delete_image"></form>';
echo '</div></div>';
include './view/components/comments.php';
echo '</div>';
include './view/components/end.php';
?>