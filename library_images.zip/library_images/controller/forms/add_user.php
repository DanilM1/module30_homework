<?php
include './model/name_user.php';
if (!$answer) {
    include './model/add_user.php';
    echo '<script type="text/javascript"> alert("Регистрация прошла успешно"); </script>'; 
}
else echo '<script type="text/javascript"> alert("Пользователь с таким именем уже существует"); </script>';
?>