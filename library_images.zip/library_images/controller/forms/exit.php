<?php
session_destroy();
header("Refresh:0");
?>