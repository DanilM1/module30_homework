<?php
    include './model/add_comment.php';
    echo '<script type="text/javascript"> alert("Комментарий добавлен. Обновите страницу"); </script>';
?>