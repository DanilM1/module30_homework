<?php
echo '<script type="text/javascript"> document.getElementById("image").remove(); </script>';
unlink('./view/images/'.$name);
include './model/delete_image.php';
echo '<script type="text/javascript"> alert("Файл удален"); </script>';
?>