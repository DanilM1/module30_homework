<?php
include './model/name_logIn.php';
if ($answer) {
    include './controller/rand.php';
    $_SESSION['user'] = $key;
    $id = $_POST['logIn'];
    include './model/add_session.php';
    echo '<script type="text/javascript"> alert("Вход выполнен"); </script>';
}
else echo '<script type="text/javascript"> alert("Вход запрещен. Проверьте логин и/или пароль"); </script>';
?>