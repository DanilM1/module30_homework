<?php
    $buf[0] = $_FILES["filename"]["name"];
    $buf[1] = substr($buf[0], 0, -4);
    $buf[2] = substr($buf[0], -4);

    if ($buf[2] == $formats[0]) {
        include './model/name_image.php';
        if (!$answer) {
            move_uploaded_file($_FILES["filename"]["tmp_name"], "./view/images/".$buf[0]);
            include './model/add_image.php';
            echo '<script type="text/javascript"> alert("Файл загружен"); </script>';
            header("Refresh:0");
        }
        else echo '<script type="text/javascript"> alert("Файл с таким именем уже существует"); </script>';  
    }
    else echo '<script type="text/javascript"> alert("Загрузить можно только файл с расширением jpg"); </script>'; 
?>