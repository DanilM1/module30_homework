<?php
    error_reporting(0);

    session_start();

    $question = $_SERVER['REQUEST_URI'];
    $name = pathinfo($question);
    $name = $name['basename'];
    
    include './model/PDO.php';
    include './view/content/nav.php';

    if ($_SESSION['user']) {
        include './model/name_session.php';
        $id = $answer['id_user'];
    }

    if ($_SERVER['REQUEST_METHOD'] === $method_send[1]) {
        if ($_FILES && $_FILES["filename"]["error"] == UPLOAD_ERR_OK) include './controller/forms/add_image.php';
        if ($_POST['add_comment']) include './controller/forms/add_comment.php';
        if ($_POST['delete_image']) include './controller/forms/delete_image.php';
        if ($_POST['register']) include './controller/forms/add_user.php';
        if ($_POST['logIn']) include './controller/forms/logIn.php';
        if ($_POST['exit']) include './controller/forms/exit.php';
    } 

    $format = substr($name, -4);
    if ($format === $formats[0]) {
        $buf[1] = substr($name, 0, -4);
        include './model/name_image.php';
        if ($answer) include './view/pages/image.php';
        else include './view/pages/home.php';
    }
    else include './view/pages/home.php';
?>