<?php
$n = rand(4, 23);
$key = '';
for ($i = 0; $i < $n; $i++) $key .= rand();
?>